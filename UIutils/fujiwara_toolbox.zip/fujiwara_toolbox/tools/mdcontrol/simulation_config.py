#シミュレーション時間。単位は秒。
simulate_time = 4
#エクスポート時に厚みをつけるかどうか。True/False
use_thickness = False

#メニューのマッチングの最大待ち時間（秒）。Noneで最大まで待つ。
max_search_time = 2