# AssetSketcherHelper
asset_sketcher_helper.py
    
##### ラベル
    説明
##### 物理追加
    選択スケッチオブジェクトに物理追加
##### 削除
    物理削除
##### 確定
    物理確定
