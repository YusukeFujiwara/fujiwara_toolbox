from fujiwara_toolbox.fjw import *


for obj in 