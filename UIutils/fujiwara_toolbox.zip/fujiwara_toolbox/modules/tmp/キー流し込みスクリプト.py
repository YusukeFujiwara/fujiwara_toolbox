from fujiwara_toolbox.fjw import *


keylist = []
#表示名　オブジェクト名
keylist.append(["",""]) #0　左
keylist.append(["",""]) #1
keylist.append(["",""]) #2
keylist.append(["",""]) #3　上
keylist.append(["",""]) #4
keylist.append(["",""]) #5
keylist.append(["",""]) #6　右
keylist.append(["",""]) #7
keylist.append(["",""]) #8
keylist.append(["",""]) #9　下
keylist.append(["",""]) #10
keylist.append(["",""]) #11 ここまで外周
keylist.append(["",""]) #12　左
keylist.append(["",""]) #13　上
keylist.append(["",""]) #14　右
keylist.append(["",""]) #15　下
keylist.append(["",""]) #16　中心

for obj in 