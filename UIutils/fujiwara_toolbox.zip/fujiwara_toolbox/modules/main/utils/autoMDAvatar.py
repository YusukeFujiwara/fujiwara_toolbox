﻿import bpy

#バックグラウンドでのオートアバター出力
bpy.ops.fujiwara_toolbox.command_302662()
#→キーフレーム挿入がバックグラウンドじゃできなかった…
